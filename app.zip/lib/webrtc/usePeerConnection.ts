"use client";

import { useEffect, useRef, useState } from "react";

const ICE_SERVERS: RTCIceServer[] = [
  { urls: "stun:stun.l.google.com:19302" },
  // Free TURN fallback (Open Relay Project) — needed once this runs on two
  // separate real devices/networks; harmless to include for local testing too.
  {
    urls: "turn:openrelay.metered.ca:80",
    username: "openrelayproject",
    credential: "openrelayproject",
  },
];

type SignalMsg =
  | { kind: "description"; description: RTCSessionDescriptionInit; from: string }
  | { kind: "candidate"; candidate: RTCIceCandidateInit; from: string };

function toSerializableDescription(description: RTCSessionDescription | null): RTCSessionDescriptionInit | null {
  if (!description) return null;
  return {
    type: description.type,
    sdp: description.sdp,
  };
}

/**
 * Connects this tab's local stream to the partner's, using BroadcastChannel
 * as the signaling transport. Local-only (same-machine tabs) works with pure
 * host candidates; STUN/TURN above is what makes it work across two real
 * devices once this ships behind a real signaling backend.
 */
export function usePeerConnection({
  code,
  selfId,
  polite,
  localStream,
}: {
  code: string | null;
  selfId: string | null;
  polite: boolean;
  localStream: MediaStream | null;
}) {
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [connectionState, setConnectionState] = useState<RTCPeerConnectionState>("new");
  const pcRef = useRef<RTCPeerConnection | null>(null);

  useEffect(() => {
    if (!code || !selfId || !localStream) return;

    const channel = new BroadcastChannel(`photobooth:rtc:${code}`);
    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });
    pcRef.current = pc;

    let makingOffer = false;
    let ignoreOffer = false;

    for (const track of localStream.getTracks()) {
      pc.addTrack(track, localStream);
    }

    const inboundRemote = new MediaStream();
    pc.ontrack = (ev) => {
      inboundRemote.addTrack(ev.track);
      setRemoteStream(new MediaStream(inboundRemote.getTracks()));
    };

    pc.onconnectionstatechange = () => setConnectionState(pc.connectionState);

    pc.onnegotiationneeded = async () => {
      try {
        makingOffer = true;
        await pc.setLocalDescription();
        const description = toSerializableDescription(pc.localDescription);
        if (description) {
          channel.postMessage({
            kind: "description",
            description,
            from: selfId,
          } satisfies SignalMsg);
        }
      } catch (err) {
        console.error("negotiation error", err);
      } finally {
        makingOffer = false;
      }
    };

    pc.onicecandidate = ({ candidate }) => {
      if (candidate) {
        channel.postMessage({
          kind: "candidate",
          candidate: candidate.toJSON(),
          from: selfId,
        } satisfies SignalMsg);
      }
    };

    channel.onmessage = async (ev: MessageEvent<SignalMsg>) => {
      const msg = ev.data;
      if (msg.from === selfId) return;
      try {
        if (msg.kind === "description") {
          const offerCollision =
            msg.description.type === "offer" &&
            (makingOffer || pc.signalingState !== "stable");
          ignoreOffer = !polite && offerCollision;
          if (ignoreOffer) return;

          await pc.setRemoteDescription(msg.description);
          if (msg.description.type === "offer") {
            await pc.setLocalDescription();
            const description = toSerializableDescription(pc.localDescription);
            if (description) {
              channel.postMessage({
                kind: "description",
                description,
                from: selfId,
              } satisfies SignalMsg);
            }
          }
        } else if (msg.kind === "candidate") {
          try {
            await pc.addIceCandidate(msg.candidate);
          } catch (err) {
            if (!ignoreOffer) throw err;
          }
        }
      } catch (err) {
        console.error("signaling error", err);
      }
    };

    return () => {
      channel.close();
      pc.close();
      pcRef.current = null;
      setRemoteStream(null);
      setConnectionState("closed");
    };
  }, [code, selfId, polite, localStream]);

  return { remoteStream, connectionState };
}
