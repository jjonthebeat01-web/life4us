"use client";

import { useEffect, useRef, useState } from "react";
import { HEARTBEAT_INTERVAL_MS, localMockStore } from "./localMockStore";
import type { SessionState } from "../types";

export const store = localMockStore;

export function useSession(code: string, partnerId: string | null) {
  const [state, setState] = useState<SessionState | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!code) return;
    const unsub = store.subscribe(code, (s) => {
      setState(s);
      setLoaded(true);
    });
    return unsub;
  }, [code]);

  useEffect(() => {
    if (!code || !partnerId) return;
    store.heartbeat(code, partnerId);
    const id = window.setInterval(() => {
      store.heartbeat(code, partnerId);
    }, HEARTBEAT_INTERVAL_MS);
    return () => window.clearInterval(id);
  }, [code, partnerId]);

  const self = partnerId && state ? state.partners[partnerId] ?? null : null;
  const partner =
    state && partnerId
      ? Object.values(state.partners).find((p) => p.id !== partnerId) ?? null
      : null;
  const isOwner = !!(self && state && state.ownerId === self.id);

  return { state, loaded, self, partner, isOwner };
}

/** Per-tab identity for the current session code, set at create/join time. */
export function usePartnerId(code: string) {
  const [partnerId, setPartnerId] = useState<string | null>(null);
  const ran = useRef(false);
  useEffect(() => {
    if (ran.current) return;
    ran.current = true;
    setPartnerId(window.sessionStorage.getItem(`photobooth:partner:${code}`));
  }, [code]);
  return partnerId;
}
