import type { FormatId, SessionState } from "../types";

/**
 * Everything a screen needs from a backend. Implement this once against
 * BroadcastChannel/localStorage (local dev), and again against AWS AppSync +
 * DynamoDB for real deployment — screens never talk to a backend directly.
 */
export interface SessionStore {
  /** Create a new session, return its code, and become its owner. */
  createSession(): Promise<{ code: string; partnerId: string }>;

  /** Join an existing session by code. Rejects if code doesn't exist. */
  joinSession(code: string): Promise<{ partnerId: string }>;

  /** Subscribe to live state for a session. Returns an unsubscribe fn. */
  subscribe(code: string, cb: (state: SessionState | null) => void): () => void;

  /** Heartbeat so the backend can detect disconnects for grace-period transfer. */
  heartbeat(code: string, partnerId: string): Promise<void>;

  /** Explicit leave (tab closed / user backs out). */
  leave(code: string, partnerId: string): Promise<void>;

  /** Template vote: record this partner's pick. */
  pickTemplate(code: string, partnerId: string, templateId: string): Promise<void>;

  /** Owner confirms once both picks match. */
  confirmTemplate(code: string, partnerId: string): Promise<void>;

  pickFormat(code: string, partnerId: string, formatId: FormatId): Promise<void>;
  confirmFormat(code: string, partnerId: string): Promise<void>;

  /** Either partner fires the synced countdown for the current shot. */
  startCountdown(code: string, partnerId: string): Promise<void>;

  /** Each device submits its own local full-res frame for the active shot. */
  submitFrame(code: string, partnerId: string, shotIndex: number, dataUrl: string): Promise<void>;

  /** Either partner votes a shot for retake. */
  voteRetake(code: string, partnerId: string, shotIndex: number): Promise<void>;

  /** Owner confirms a retake once 2 votes are in; loops capture back to that shot. */
  confirmRetake(code: string, partnerId: string, shotIndex: number): Promise<void>;

  /** Either partner can change the filter; live-synced, no vote needed. */
  setFilter(code: string, partnerId: string, filterId: string): Promise<void>;

  /** Advance the flow (e.g. after filter -> shared view). */
  advanceStep(code: string, partnerId: string, step: SessionState["step"]): Promise<void>;
}
